import streamlit as st
from PIL import Image
import paypalrestsdk
import uuid

paypalrestsdk.configure({
    "mode": "sandbox",
    "client_id": st.secrets["PAYPAL_CLIENT_ID"],
    "client_secret": st.secrets["PAYPAL_CLIENT_SECRET"]
})

def create_payment(amount, description, return_url="https://www.google.com", cancel_url="https://www.google.com"):
    payment = paypalrestsdk.Payment({
        "intent": "sale",
        "payer": {"payment_method": "paypal"},
        "redirect_urls": {"return_url": return_url, "cancel_url": cancel_url},
        "transactions": [{
            "item_list": {"items": [{
                "name": description,
                "sku": str(uuid.uuid4()),
                "price": str(amount),
                "currency": "EUR",
                "quantity": 1
            }]},
            "amount": {"total": str(amount), "currency": "EUR"},
            "description": description
        }]
    })
    return payment.links[1].href if payment.create() else None

st.title("👶 Visualize Your Children")
st.write("Upload 3 photos of yourself and 3 photos of the other person.")

your_photos = st.file_uploader("Your 3 photos", type=["jpg", "jpeg", "png"], accept_multiple_files=True)
other_photos = st.file_uploader("The other person's 3 photos", type=["jpg", "jpeg", "png"], accept_multiple_files=True)

if st.button("Pay 2€ and see the results 👶💕"):
    link_payment2 = create_payment(2, "Children Visualization")
    if link_payment2:
        st.markdown(f"[👉 Click here to pay with PayPal]({link_payment2})")
    else:
        st.error("Payment error. Check PayPal credentials.")

if your_photos and other_photos:
    if len(your_photos) == 3 and len(other_photos) == 3:
        st.info("⚠️ After payment, we will generate realistic images of the children.")
        for f in your_photos + other_photos:
            img = Image.open(f)
            st.image(img, width=150)
    else:
        st.warning("You must upload exactly 3 photos of yourself and 3 of the other person.")
