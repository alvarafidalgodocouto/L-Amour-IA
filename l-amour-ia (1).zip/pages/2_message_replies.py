import streamlit as st
from openai import OpenAI

client = OpenAI(api_key=st.secrets["OPENAI_API_KEY"])

st.title("💬 Message Reply Suggestions")
st.write("Paste a message and get expert reply suggestions.")

if "chat2" not in st.session_state:
    st.session_state.chat2 = []

for msg in st.session_state.chat2:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

if user_input := st.chat_input("Paste the message here..."):
    st.session_state.chat2.append({"role": "user", "content": user_input})
    with st.chat_message("user"):
        st.markdown(user_input)

    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "You are a love communication expert. Help create an empathetic, romantic, natural reply."},
            {"role": "user", "content": user_input}
        ]
    )
    reply = response.choices[0].message.content
    st.session_state.chat2.append({"role": "assistant", "content": reply})
    with st.chat_message("assistant"):
        st.markdown(reply)
