import streamlit as st
from openai import OpenAI

client = OpenAI(api_key=st.secrets["OPENAI_API_KEY"])

st.title("💌 Love Advice Chat")
st.write("Get personalized love advice from our AI therapist.")

if "chat1" not in st.session_state:
    st.session_state.chat1 = []

for msg in st.session_state.chat1:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

if user_input := st.chat_input("Share your feelings..."):
    st.session_state.chat1.append({"role": "user", "content": user_input})
    with st.chat_message("user"):
        st.markdown(user_input)

    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "You are an empathetic therapist giving human love advice."},
            {"role": "user", "content": user_input}
        ]
    )
    reply = response.choices[0].message.content
    st.session_state.chat1.append({"role": "assistant", "content": reply})
    with st.chat_message("assistant"):
        st.markdown(reply)
