import streamlit as st
from PIL import Image
import paypalrestsdk
import uuid

paypalrestsdk.configure({
    "mode": "sandbox",
    "client_id": st.secrets["PAYPAL_CLIENT_ID"],
    "client_secret": st.secrets["PAYPAL_CLIENT_SECRET"]
})

def create_payment(amount, description, return_url="https://www.google.com", cancel_url="https://www.google.com"):
    payment = paypalrestsdk.Payment({
        "intent": "sale",
        "payer": {"payment_method": "paypal"},
        "redirect_urls": {"return_url": return_url, "cancel_url": cancel_url},
        "transactions": [{
            "item_list": {"items": [{
                "name": description,
                "sku": str(uuid.uuid4()),
                "price": str(amount),
                "currency": "EUR",
                "quantity": 1
            }]},
            "amount": {"total": str(amount), "currency": "EUR"},
            "description": description
        }]
    })
    return payment.links[1].href if payment.create() else None

st.title("✨ Discover Your Soulmate")
st.write("Fill in your details and upload a selfie to generate your soulmate.")

name = st.text_input("Your name:")
age = st.number_input("Your age:", min_value=16, max_value=100, step=1)
height = st.text_input("Your height:")
fav_color = st.text_input("Your favorite color:")
hobbies = st.text_area("Your hobbies:")
profession = st.text_input("Your profession:")
selfie = st.file_uploader("Upload a selfie 📷", type=["jpg", "png", "jpeg"])

if st.button("Pay 1€ to generate soulmate 💕"):
    link_payment = create_payment(1, "Soulmate Drawing")
    if link_payment:
        st.markdown(f"[👉 Click here to pay with PayPal]({link_payment})")
    else:
        st.error("Payment error. Check PayPal credentials.")

if name and age and height and fav_color and hobbies and profession and selfie:
    st.info("⚠️ After payment, we will generate your soulmate!")
    img = Image.open(selfie)
    st.image(img, caption="(Your selfie uploaded)")
